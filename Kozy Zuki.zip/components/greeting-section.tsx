"use client"

import { useEffect, useState } from "react"
import { useUser } from "./user-context"

export function GreetingSection() {
  const { name } = useUser()
  const [greeting, setGreeting] = useState("")
  const [timeOfDay, setTimeOfDay] = useState<"morning" | "afternoon" | "evening">("morning")

  useEffect(() => {
    const hour = new Date().getHours()

    if (hour < 12) {
      setTimeOfDay("morning")
      setGreeting("Good morning")
    } else if (hour < 18) {
      setTimeOfDay("afternoon")
      setGreeting("Good afternoon")
    } else {
      setTimeOfDay("evening")
      setGreeting("Good evening")
    }
  }, [])

  const displayText = name ? `${greeting}, ${name}` : "Feeling good today?"

  const getGradientClass = () => {
    switch (timeOfDay) {
      case "morning":
        return "from-blue-400 to-blue-600"
      case "afternoon":
        return "from-amber-400 to-orange-500"
      case "evening":
        return "from-purple-400 to-indigo-600"
      default:
        return "from-blue-400 to-blue-600"
    }
  }

  return (
    <div className={`bg-gradient-to-r ${getGradientClass()} rounded-2xl p-8 md:p-10 mb-8 text-white shadow-lg`}>
      <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold text-balance leading-tight">{displayText}</h1>
      <p className="text-white/95 mt-3 text-lg md:text-xl font-medium">
        {name ? "Let's make today productive" : "What would you like to accomplish today?"}
      </p>
    </div>
  )
}
