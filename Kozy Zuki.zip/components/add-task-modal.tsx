"use client"

import type React from "react"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"

interface AddTaskModalProps {
  isOpen: boolean
  onClose: () => void
  onAdd: (task: {
    title: string
    description?: string
    dueDate: string
    priority: "low" | "medium" | "high"
  }) => void
}

const getQuickDate = (preset: string): string => {
  const today = new Date()
  const date = new Date(today)

  switch (preset) {
    case "today":
      break
    case "tomorrow":
      date.setDate(date.getDate() + 1)
      break
    case "next-week":
      date.setDate(date.getDate() + 7)
      break
    case "next-month":
      date.setMonth(date.getMonth() + 1)
      break
    case "in-3-days":
      date.setDate(date.getDate() + 3)
      break
    default:
      break
  }

  return date.toISOString().split("T")[0]
}

export function AddTaskModal({ isOpen, onClose, onAdd }: AddTaskModalProps) {
  const [title, setTitle] = useState("")
  const [description, setDescription] = useState("")
  const [dueDate, setDueDate] = useState("")
  const [priority, setPriority] = useState<"low" | "medium" | "high">("medium")

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    if (!title.trim() || !dueDate) return

    onAdd({
      title: title.trim(),
      description: description.trim() || undefined,
      dueDate,
      priority,
    })

    setTitle("")
    setDescription("")
    setDueDate("")
    setPriority("medium")
  }

  const handleQuickDate = (preset: string) => {
    setDueDate(getQuickDate(preset))
  }

  if (!isOpen) return null

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
      <div className="bg-card rounded-2xl shadow-lg max-w-md w-full max-h-[90vh] overflow-y-auto">
        {/* Header */}
        <div className="flex items-center justify-between p-6 border-b border-border">
          <h2 className="text-xl font-bold text-foreground">Add New Task</h2>
          <button onClick={onClose} className="p-1 hover:bg-muted rounded-lg transition-colors text-lg">
            ✕
          </button>
        </div>

        {/* Form */}
        <form onSubmit={handleSubmit} className="p-6 space-y-4">
          <div>
            <label className="block text-sm font-medium text-foreground mb-2">Task Title *</label>
            <Input
              type="text"
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              placeholder="What do you need to do?"
              className="w-full"
              required
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-foreground mb-2">Description</label>
            <textarea
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              placeholder="Add more details (optional)"
              className="w-full px-3 py-2 border border-border rounded-xl bg-background text-foreground placeholder-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary resize-none"
              rows={3}
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-foreground mb-3">Due Date *</label>
            <Input
              type="date"
              value={dueDate}
              onChange={(e) => setDueDate(e.target.value)}
              className="w-full mb-3"
              required
            />
            <div className="grid grid-cols-2 gap-2">
              <button
                type="button"
                onClick={() => handleQuickDate("today")}
                className={`px-3 py-2 rounded-lg text-sm font-medium transition-all ${
                  dueDate === getQuickDate("today")
                    ? "bg-primary text-white"
                    : "bg-muted text-foreground hover:bg-muted/80"
                }`}
              >
                Today
              </button>
              <button
                type="button"
                onClick={() => handleQuickDate("tomorrow")}
                className={`px-3 py-2 rounded-lg text-sm font-medium transition-all ${
                  dueDate === getQuickDate("tomorrow")
                    ? "bg-primary text-white"
                    : "bg-muted text-foreground hover:bg-muted/80"
                }`}
              >
                Tomorrow
              </button>
              <button
                type="button"
                onClick={() => handleQuickDate("in-3-days")}
                className={`px-3 py-2 rounded-lg text-sm font-medium transition-all ${
                  dueDate === getQuickDate("in-3-days")
                    ? "bg-primary text-white"
                    : "bg-muted text-foreground hover:bg-muted/80"
                }`}
              >
                In 3 Days
              </button>
              <button
                type="button"
                onClick={() => handleQuickDate("next-week")}
                className={`px-3 py-2 rounded-lg text-sm font-medium transition-all ${
                  dueDate === getQuickDate("next-week")
                    ? "bg-primary text-white"
                    : "bg-muted text-foreground hover:bg-muted/80"
                }`}
              >
                Next Week
              </button>
              <button
                type="button"
                onClick={() => handleQuickDate("next-month")}
                className={`px-3 py-2 rounded-lg text-sm font-medium transition-all col-span-2 ${
                  dueDate === getQuickDate("next-month")
                    ? "bg-primary text-white"
                    : "bg-muted text-foreground hover:bg-muted/80"
                }`}
              >
                Next Month
              </button>
            </div>
          </div>

          <div>
            <label className="block text-sm font-medium text-foreground mb-2">Priority</label>
            <select
              value={priority}
              onChange={(e) => setPriority(e.target.value as "low" | "medium" | "high")}
              className="w-full px-3 py-2 border border-border rounded-xl bg-background text-foreground focus:outline-none focus:ring-2 focus:ring-primary"
            >
              <option value="low">Low</option>
              <option value="medium">Medium</option>
              <option value="high">High</option>
            </select>
          </div>

          <div className="flex gap-3 pt-4">
            <Button type="button" onClick={onClose} variant="outline" className="flex-1 bg-transparent">
              Cancel
            </Button>
            <Button
              type="submit"
              className="flex-1 bg-gradient-to-r from-primary to-accent text-white hover:opacity-90"
            >
              Add Task
            </Button>
          </div>
        </form>
      </div>
    </div>
  )
}
