"use client"

export function InspirationView() {
  const inspirations = [
    {
      id: 1,
      title: "Break it down",
      description: "Large tasks feel overwhelming. Try breaking them into smaller, manageable steps.",
      icon: "📋",
    },
    {
      id: 2,
      title: "Time blocking",
      description: "Dedicate specific time blocks for focused work on your most important tasks.",
      icon: "⏱️",
    },
    {
      id: 3,
      title: "Pomodoro technique",
      description: "Work in 25-minute intervals with short breaks to maintain focus and energy.",
      icon: "🍅",
    },
    {
      id: 4,
      title: "Priority matrix",
      description: "Categorize tasks by urgency and importance to focus on what truly matters.",
      icon: "📊",
    },
    {
      id: 5,
      title: "Celebrate wins",
      description: "Acknowledge completed tasks. Small wins build momentum and motivation.",
      icon: "🎉",
    },
    {
      id: 6,
      title: "Review & reflect",
      description: "End each day reviewing what you accomplished and planning for tomorrow.",
      icon: "🔍",
    },
  ]

  return (
    <div className="p-4 md:p-8 max-w-6xl mx-auto">
      <div className="mb-8">
        <div className="flex items-center gap-2 mb-2">
          <span className="text-2xl">✨</span>
          <h2 className="text-3xl font-bold text-foreground">Inspiration</h2>
        </div>
        <p className="text-muted-foreground">Tips and strategies to boost your productivity</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {inspirations.map((item) => (
          <div key={item.id} className="bg-card border border-border rounded-lg p-6 hover:shadow-md transition-shadow">
            <div className="text-3xl mb-3">{item.icon}</div>
            <h3 className="font-semibold text-foreground mb-2">{item.title}</h3>
            <p className="text-sm text-muted-foreground">{item.description}</p>
          </div>
        ))}
      </div>
    </div>
  )
}
