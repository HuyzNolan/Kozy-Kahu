"use client"

import { useState } from "react"
import { useToast } from "./toast-provider"
import { TaskCard } from "./task-card"
import { AddTaskModal } from "./add-task-modal"
import { GreetingSection } from "./greeting-section"
import { useView } from "./view-context"
import { ViewModeToggle } from "./view-mode-toggle" // Import ViewModeToggle

interface Task {
  id: string
  title: string
  description?: string
  dueDate: string
  priority: "low" | "medium" | "high"
  completed: boolean
}

const SAMPLE_TASKS: Task[] = [
  {
    id: "1",
    title: "Design new landing page",
    description: "Create a modern, minimalistic design for the homepage",
    dueDate: "2025-10-25",
    priority: "high",
    completed: false,
  },
  {
    id: "2",
    title: "Review pull requests",
    description: "Check and approve pending code reviews",
    dueDate: "2025-10-24",
    priority: "medium",
    completed: false,
  },
  {
    id: "3",
    title: "Update documentation",
    dueDate: "2025-10-26",
    priority: "low",
    completed: false,
  },
  {
    id: "4",
    title: "Fix bug in auth flow",
    description: "Users unable to reset password",
    dueDate: "2025-10-23",
    priority: "high",
    completed: false,
  },
]

export function TasksView() {
  const [tasks, setTasks] = useState<Task[]>(SAMPLE_TASKS)
  const [isAddModalOpen, setIsAddModalOpen] = useState(false)
  const [undoTimeouts, setUndoTimeouts] = useState<Record<string, NodeJS.Timeout>>({})
  const { addToast } = useToast()
  const { viewMode } = useView()

  const handleAddTask = (newTask: Omit<Task, "id" | "completed">) => {
    const task: Task = {
      ...newTask,
      id: Date.now().toString(),
      completed: false,
    }
    setTasks([task, ...tasks])
    setIsAddModalOpen(false)
  }

  const handleUpdateTask = (id: string, updatedFields: Partial<Task>) => {
    setTasks(tasks.map((t) => (t.id === id ? { ...t, ...updatedFields } : t)))
    addToast({
      message: "Task updated successfully",
      duration: 3000,
    })
  }

  const handleToggleTask = (id: string) => {
    const task = tasks.find((t) => t.id === id)
    if (!task) return

    if (!task.completed) {
      // Task is being marked as complete - remove from view and show undo notification
      setTasks(tasks.map((t) => (t.id === id ? { ...t, completed: true } : t)))

      // Clear any existing timeout for this task
      if (undoTimeouts[id]) {
        clearTimeout(undoTimeouts[id])
      }

      // Set up undo timeout (5 seconds)
      const timeout = setTimeout(() => {
        setUndoTimeouts((prev) => {
          const newTimeouts = { ...prev }
          delete newTimeouts[id]
          return newTimeouts
        })
      }, 5000)

      setUndoTimeouts((prev) => ({ ...prev, [id]: timeout }))

      addToast({
        message: `"${task.title}" completed!`,
        action: {
          label: "Undo",
          onClick: () => {
            handleUndoCompletion(id)
          },
        },
        duration: 5000,
      })
    } else {
      // Task is being unchecked - just toggle it back
      setTasks(tasks.map((t) => (t.id === id ? { ...t, completed: false } : t)))
    }
  }

  const handleUndoCompletion = (id: string) => {
    setTasks(tasks.map((t) => (t.id === id ? { ...t, completed: false } : t)))

    // Clear the timeout
    if (undoTimeouts[id]) {
      clearTimeout(undoTimeouts[id])
      setUndoTimeouts((prev) => {
        const newTimeouts = { ...prev }
        delete newTimeouts[id]
        return newTimeouts
      })
    }

    addToast({
      message: "Task restored to your active list",
      duration: 3000,
    })
  }

  const handleDeleteTask = (id: string) => {
    setTasks(tasks.filter((task) => task.id !== id))
    // Clear any pending undo timeout
    if (undoTimeouts[id]) {
      clearTimeout(undoTimeouts[id])
    }
  }

  const activeTasks = tasks.filter((t) => !t.completed)

  return (
    <div className="p-4 md:p-8 max-w-6xl mx-auto">
      <GreetingSection />

      <div className="mb-8 flex items-center justify-between">
        <div>
          <h2 className="text-3xl font-bold text-foreground mb-2">Tasks</h2>
          <p className="text-muted-foreground">{activeTasks.length} active tasks</p>
        </div>
        <div className="hidden md:block">
          <ViewModeToggle />
        </div>
      </div>

      {viewMode === "board" ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 mb-8">
          {activeTasks.length > 0 ? (
            activeTasks.map((task) => (
              <TaskCard
                key={task.id}
                task={task}
                onToggle={handleToggleTask}
                onDelete={handleDeleteTask}
                onUpdate={handleUpdateTask}
              />
            ))
          ) : (
            <div className="col-span-full text-center py-12">
              <p className="text-muted-foreground text-lg">No active tasks. Great job!</p>
            </div>
          )}
        </div>
      ) : (
        <div className="space-y-3 mb-8 max-w-2xl">
          {activeTasks.length > 0 ? (
            activeTasks.map((task) => (
              <div
                key={task.id}
                className="bg-card border border-border rounded-lg p-4 hover:shadow-md transition-shadow"
              >
                <div className="flex items-start gap-3">
                  {/* Checkbox */}
                  <button
                    onClick={() => handleToggleTask(task.id)}
                    className="mt-1 flex-shrink-0 w-6 h-6 rounded-full border-2 border-primary hover:bg-primary/10 transition-colors flex items-center justify-center"
                    aria-label="Toggle task"
                  >
                    {task.completed && <span className="text-primary">✓</span>}
                  </button>

                  {/* Task content */}
                  <div className="flex-1 min-w-0">
                    <h3 className="font-semibold text-foreground truncate">{task.title}</h3>
                    {task.description && (
                      <p className="text-sm text-muted-foreground line-clamp-2 mt-1">{task.description}</p>
                    )}
                    <div className="flex items-center gap-3 mt-2 flex-wrap">
                      <span className="text-xs px-2 py-1 rounded-full bg-muted text-muted-foreground">
                        {new Date(task.dueDate).toLocaleDateString("en-US", {
                          month: "short",
                          day: "numeric",
                        })}
                      </span>
                      <span
                        className={`text-xs px-2 py-1 rounded-full font-medium ${
                          task.priority === "high"
                            ? "bg-red-100 text-red-700 dark:bg-red-900/30 dark:text-red-400"
                            : task.priority === "medium"
                              ? "bg-yellow-100 text-yellow-700 dark:bg-yellow-900/30 dark:text-yellow-400"
                              : "bg-green-100 text-green-700 dark:bg-green-900/30 dark:text-green-400"
                        }`}
                      >
                        {task.priority}
                      </span>
                    </div>
                  </div>

                  {/* Actions */}
                  <div className="flex-shrink-0 flex gap-2">
                    <button
                      onClick={() => {
                        // Edit action
                      }}
                      className="text-muted-foreground hover:text-foreground transition-colors"
                      aria-label="Edit task"
                    >
                      ✎
                    </button>
                    <button
                      onClick={() => handleDeleteTask(task.id)}
                      className="text-muted-foreground hover:text-destructive transition-colors"
                      aria-label="Delete task"
                    >
                      🗑️
                    </button>
                  </div>
                </div>
              </div>
            ))
          ) : (
            <div className="text-center py-12">
              <p className="text-muted-foreground text-lg">No active tasks. Great job!</p>
            </div>
          )}
        </div>
      )}

      {/* Floating Add button */}
      <button
        onClick={() => setIsAddModalOpen(true)}
        className="fixed bottom-8 right-8 md:bottom-12 md:right-12 w-14 h-14 rounded-full bg-gradient-to-br from-primary to-accent text-white shadow-lg hover:shadow-xl transition-shadow flex items-center justify-center text-2xl"
      >
        +
      </button>

      {/* Add Task Modal */}
      <AddTaskModal isOpen={isAddModalOpen} onClose={() => setIsAddModalOpen(false)} onAdd={handleAddTask} />
    </div>
  )
}
