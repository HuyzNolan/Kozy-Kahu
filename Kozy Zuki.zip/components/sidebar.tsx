"use client"

interface SidebarProps {
  activeTab: "tasks" | "inspiration" | "settings"
  setActiveTab: (tab: "tasks" | "inspiration" | "settings") => void
}

export function Sidebar({ activeTab, setActiveTab }: SidebarProps) {
  const tabs = [
    { id: "tasks", label: "Tasks", icon: "✓" },
    { id: "inspiration", label: "Inspiration", icon: "💡" },
    { id: "settings", label: "Settings", icon: "⚙️" },
  ] as const

  return (
    <aside className="w-64 border-r border-border bg-sidebar flex flex-col">
      {/* Logo */}
      <div className="p-6 border-b border-sidebar-border">
        <div className="flex items-center gap-4">
          <div className="w-14 h-14 rounded-lg bg-gradient-to-br from-primary to-accent flex items-center justify-center flex-shrink-0">
            <span className="text-white font-bold text-xl">F</span>
          </div>
          <div className="min-w-0">
            <h1 className="font-bold text-sm text-foreground leading-tight">FocusFlow AI</h1>
            <p className="text-xs text-muted-foreground">Your AI assistant</p>
          </div>
        </div>
      </div>

      {/* Navigation */}
      <nav className="flex-1 p-4 space-y-2">
        {tabs.map(({ id, label, icon }) => (
          <button
            key={id}
            onClick={() => setActiveTab(id)}
            className={`w-full flex items-center gap-3 px-4 py-3 rounded-lg transition-all ${
              activeTab === id
                ? "bg-sidebar-primary text-sidebar-primary-foreground"
                : "text-sidebar-foreground hover:bg-sidebar-accent hover:text-sidebar-accent-foreground"
            }`}
          >
            <span className="text-lg">{icon}</span>
            <span className="font-medium">{label}</span>
          </button>
        ))}
      </nav>

      {/* Footer */}
      <div className="p-4 border-t border-sidebar-border">
        <p className="text-xs text-muted-foreground text-center">Made with ✨ for focus</p>
      </div>
    </aside>
  )
}
