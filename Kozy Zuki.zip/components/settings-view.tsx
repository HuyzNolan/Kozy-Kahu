"use client"

import { useUser } from "./user-context"
import { ThemeToggle } from "./theme-toggle"
import { ViewModeToggle } from "./view-mode-toggle"

export function SettingsView() {
  const { name, setName } = useUser()

  return (
    <div className="p-4 md:p-8 max-w-2xl mx-auto">
      <h2 className="text-3xl font-bold text-foreground mb-8">Settings</h2>

      <div className="space-y-6">
        {/* Profile Section */}
        <div className="bg-card border border-border rounded-lg p-6">
          <div className="flex items-center gap-3 mb-4">
            <span className="text-xl">👤</span>
            <h3 className="font-semibold text-foreground">Profile</h3>
          </div>
          <div className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-foreground mb-2">Display Name</label>
              <input
                type="text"
                placeholder="Your name"
                value={name}
                onChange={(e) => setName(e.target.value)}
                className="w-full px-3 py-2 border border-border rounded-lg bg-background text-foreground placeholder-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-foreground mb-2">Email</label>
              <input
                type="email"
                placeholder="your@email.com"
                className="w-full px-3 py-2 border border-border rounded-lg bg-background text-foreground placeholder-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary"
              />
            </div>
          </div>
        </div>

        {/* Preferences Section */}
        <div className="bg-card border border-border rounded-lg p-6">
          <div className="flex items-center gap-3 mb-4">
            <span className="text-xl">🎨</span>
            <h3 className="font-semibold text-foreground">Preferences</h3>
          </div>
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <label className="text-sm text-foreground">Dark Mode</label>
              <ThemeToggle />
            </div>
            <div className="flex items-center justify-between">
              <label className="text-sm text-foreground">View Mode</label>
              <ViewModeToggle />
            </div>
          </div>
        </div>

        {/* Notifications Section */}
        <div className="bg-card border border-border rounded-lg p-6">
          <div className="flex items-center gap-3 mb-4">
            <span className="text-xl">🔔</span>
            <h3 className="font-semibold text-foreground">Notifications</h3>
          </div>
          <div className="space-y-4">
            <label className="flex items-center gap-3 cursor-pointer">
              <input type="checkbox" defaultChecked className="w-4 h-4" />
              <span className="text-sm text-foreground">Task reminders</span>
            </label>
            <label className="flex items-center gap-3 cursor-pointer">
              <input type="checkbox" defaultChecked className="w-4 h-4" />
              <span className="text-sm text-foreground">Daily digest</span>
            </label>
          </div>
        </div>
      </div>
    </div>
  )
}
