import type React from "react"
import type { Metadata } from "next"
import { Poppins } from "next/font/google"
import { ToastProvider } from "@/components/toast-provider"
import { ThemeProvider } from "@/components/theme-provider"
import { ViewProvider } from "@/components/view-context"
import "./globals.css"

const _poppins = Poppins({
  subsets: ["latin"],
  weight: ["400", "500", "600", "700"],
  variable: "--font-sans",
})

export const metadata: Metadata = {
  title: "v0 App",
  description: "Created with v0",
  generator: "v0.app",
}

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode
}>) {
  return (
    <html lang="en" style={{ "--font-sans": _poppins.style.fontFamily } as React.CSSProperties}>
      <body className={`font-sans antialiased`}>
        <ThemeProvider attribute="class" defaultTheme="system" enableSystem>
          <ViewProvider>
            <ToastProvider>{children}</ToastProvider>
          </ViewProvider>
        </ThemeProvider>
      </body>
    </html>
  )
}
